extern evptr mk_evtree();
extern struct stringlist *mk_stringlist();
extern int yyparse();
extern void printtree();
extern int eval();
extern void printtree();

extern int yylex (void);
extern int yyerror();

extern evptr shyyval;

